README 


Activity 1

How to compile and run:

- Open folder src
- Open folder Activity1
- Open and save files Stack.java, Stackmain.java
- Compile files Stack.java, Stackmain.java
- Run the main class file Stackmain.java


Task 1

How to compile and run:

- Open folder src
- Open folder Task1
- Open and save files Stack.java, Stackmain.java
- Compile files Stack.java, Stackmain.java
- Run the main class file Stackmain.java


Activity 2

How to compile and run:

- Open folder src
- Open folder Activity2
- Open and save files Stack.java, ArrayStack.java, Test.java
- Compile files Stack.java, ArrayStack.java, Test.java
- Run the main class file Test.java


Activity 3

How to compile and run:

- Open folder src
- Open folder Activity2
- Open and save file Stack.java
- Open folder Activity3
- Open and save files LinkedStack.java, Test.java
- Compile files Stack.java, ArrayStack.java, Test.java
- Run the main class file Test.java


Task 2

How to compile and run:

- Open folder src
- Open folder Task2
- Open and save files Stack.java, ArrayStack.java, LinkedStack.java, StackTesting.java
- Compile files Stack.java, ArrayStack.java, LinkedStack.java, StackTesting.java
- Run the main class file StackTesting.java


Task 3

How to compile and run:

- Open folder src
- Open folder Task2
- Open and save file Stack.java
- Open folder Task3
- Open and save files ArrayStack.java, LinkedStack.java, StackTesting.java
- Compile files Stack.java, ArrayStack.java, LinkedStack.java, StackTesting.java
- Run the main class file StackTesting.java