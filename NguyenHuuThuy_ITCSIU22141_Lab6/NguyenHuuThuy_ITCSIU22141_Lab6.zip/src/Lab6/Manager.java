package Lab6;

public interface Manager 
{
	public void handleCrisis();
}