README 


How to compile and run the code:
+ Open folder src
+ Open files: Person, Employee and EmployeeTest
+ Compile


Example:
+ Enter the number of persons: 
3

Enter details for employee 1: 
+ Enter first name: 
Mike
+ Enter last name: 
Jordan
+ Enter height in feet: 
6
+ Enter height in inches: 
3
+ Enter employee ID: 
11
+ Enter hourly pay: 
50
+ Enter hours of work: 
50
Total earn: 2750.0

Enter details for employee 2: 
+ Enter the number of persons: 
3

Enter details for employee 1: 
+ Enter first name: 
Mike
+ Enter last name: 
Jordan
+ Enter height in feet: 
6
+ Enter height in inches: 
3
+ Enter employee ID: 
11
+ Enter hourly pay: 
50
+ Enter hours of work: 
50
Total earn: 2750.0

Enter details for employee 3: 
+ Enter the number of persons: 
3

Enter details for employee 1: 
+ Enter first name: 
Kobe
+ Enter last name: 
Japan
+ Enter height in feet: 
5
+ Enter height in inches: 
11
+ Enter employee ID: 
12
+ Enter hourly pay: 
40
+ Enter hours of work: 
30
Total earn: 1200.0

Name: Mike Jordan
They are 6.0’ 3.0“
They make $57.50
They have the employee ID 11

Name: mike Jordan
They are 6.0’ 3.0“
They make $57.50
They have the employee ID 11

Name: Kobe Japan
They are 5.0’ 11.0“
They make $46.00
They have the employee ID 11

Employee 1 and Employee 2 are equal.
Employee 1 and Employee 3 are not equal.
Employee 2 and Employee 3 are not equal.

